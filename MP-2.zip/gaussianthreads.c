/*****************************************************
*
* Gaussian elimination
*
* Parallel version using p-threads
*
*****************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <pthread.h>
#include <semaphore.h>
#include <errno.h>
#include <unistd.h>

#define MAX_SIZE 2048
typedef double matrix[MAX_SIZE][MAX_SIZE];
int N; /* matrix size */
int maxnum; /* max number of element*/
char *Init; /* matrix init type */
int PRINT; /* print switch */
matrix A; /* matrix A */
double b[MAX_SIZE]; /* vector b */
double y[MAX_SIZE]; /* vector y */

matrix A_copy;
double b_copy[MAX_SIZE];
double y_copy[MAX_SIZE];

/* forward declarations */
void work(void);
void Init_Matrix(void);
void Print_Matrix(void);
void Init_Default(void);
int Read_Options(int, char **);

struct thread_info {
	int thread_id;
	int row_idx;
	int row_count;
};

#define MAX_THREADS 8
struct thread_info thread_init_array[MAX_THREADS];
sem_t sem_array[MAX_THREADS];
pthread_t threads[MAX_THREADS];

void copy_matrices() {
	int i = 0, j = 0;
	for (i = 0; i < N; i++) {
		for (j = 0; j < N; j++) {
			A_copy[i][j] = A[i][j];
		}
		b_copy[i] = b[i];
		y_copy[i] = y[i];
	}
}

Print_Matrix_copies() {
	int i, j;
	printf("Matrix A_copy : \n");

	for (i = 0; i < N; i++) {
		printf("[");
		for (j = 0; j < N; j++)
			printf(" %5.2f, ", A_copy[i][j]);

		printf("]\n");
	}

	printf("Vector b_copy : \n[");
	for (j = 0; j < N; j++)
		printf(" %5.2f, ", b_copy[j]);

	printf("]\n");
	printf("Vector y_copy : \n[");
	for (j = 0; j < N; j++)
		printf(" %5.2f, ", y_copy[j]);

	printf("]\n");
	printf("\n\n");
}

void sem_init_fn() {
	int i = 0;
	for (i = 0; i < MAX_THREADS; i++) {
		sem_init(&sem_array[i], 0, 0);
	}
}

void sem_post_fn(int id) {
	int i = 0;
	for (i = id + 1; i < MAX_THREADS; i++) {
		sem_post(&sem_array[i]);
	}
}

void* work_thread(void *x) {
	struct thread_info *info = (struct thread_info*)x;

	int i = 0, j = 0, k = 0;
	int row_num = info->row_idx*info->row_count;

	for (k = 0; k < row_num; k++) {
		sem_wait(&sem_array[info->thread_id]);
		for (i = row_num; i < row_num + info->row_count; i++) {
			for (j = k + 1; j < N; j++) {
				A_copy[i][j] = A_copy[i][j] - A_copy[i][k] * A_copy[k][j];
			}
			b_copy[i] = b_copy[i] - A_copy[i][k] * y_copy[k];
			A_copy[i][k] = 0.0;
		}
	}

	for (k = row_num; k < row_num + info->row_count; k++) {
		for (j = k + 1; j < N; j++) {
			A_copy[k][j] = A_copy[k][j] / A_copy[k][k];
		}
		y_copy[k] = b_copy[k] / A_copy[k][k];
		A_copy[k][k] = 1.0;
		sem_post_fn(info->thread_id);

		for (i = k + 1; i < row_num + info->row_count; i++) {
			for (j = k + 1; j < N; j++) {
				A_copy[i][j] = A_copy[i][j] - A_copy[i][k] * A_copy[k][j];
			}
			b_copy[i] = b_copy[i] - A_copy[i][k] * y_copy[k];
			A_copy[i][k] = 0.0;
		}
	}
}

int main(int argc, char **argv) {
	int i, timestart, timeend, iter;

	Init_Default(); /* Init_Default values */
	Read_Options(argc, argv); /* Read arguments */
	Init_Matrix(); /* Init the matrix */
	copy_matrices();
	/*Print_Matrix_copies()*/;
	//work();

	sem_init_fn();
	for (i = 1; i < MAX_THREADS; i++) {
		thread_init_array[i].thread_id = i;
		thread_init_array[i].row_idx = i;
		thread_init_array[i].row_count = MAX_SIZE / MAX_THREADS;
		pthread_create(&threads[i], NULL, &work_thread, (void*)&thread_init_array[i]);
	}
	thread_init_array[0].thread_id = 0;
	thread_init_array[0].row_idx = 0;
	thread_init_array[0].row_count = MAX_SIZE / MAX_THREADS;
	work_thread((void*)&thread_init_array[0]);
	void *data;
	for (i = 1; i < MAX_THREADS; i++) {
		pthread_join(threads[i], data);
	}
	if (PRINT == 1) Print_Matrix();
	//Print_Matrix_copies();
}

void work(void) {
	int i, j, k;
	/* Gaussian elimination algorithm, Algo 8.4 from Grama */
	for (k = 0; k < N; k++) {
		/* Outer loop */
		for (j = k + 1; j < N; j++)
			A[k][j] = A[k][j] / A[k][k]; /* Division step */
		y[k] = b[k] / A[k][k]; A[k][k] = 1.0;
		for (i = k + 1; i < N; i++) {
			for (j = k + 1; j < N; j++)
				A[i][j] = A[i][j] - A[i][k] * A[k][j]; /* Elimination step */
			b[i] = b[i] - A[i][k] * y[k]; A[i][k] = 0.0;
		}
	}
}

void Init_Matrix() {
	int i, j;
	printf("\nsize = %dx%d ", N, N);
	printf("\nmaxnum = %d \n", maxnum);
	printf("Init = %s \n", Init);
	printf("Initializing matrix...");

	if (strcmp(Init, "rand") == 0) {
		for (i = 0; i < N; i++) {
			for (j = 0; j < N; j++) {
				if (i == j) /* diagonal dominance */
					A[i][j] = (double)(rand() % maxnum) + 5.0;
				else A[i][j] = (double)(rand() % maxnum) + 1.0;
			}
		}
	}

	if (strcmp(Init, "fast") == 0) {
		for (i = 0; i < N; i++) {
			for (j = 0; j < N; j++) {
				if (i == j) /* diagonal dominance */
					A[i][j] = 5.0;
				else A[i][j] = 2.0;
			}
		}
	}

	/* Initialize vectors b and y */
	for (i = 0; i < N; i++) {
		b[i] = 2.0;
		y[i] = 1.0;
	}

	printf("done \n\n");
	if (PRINT == 1) Print_Matrix();
}

void Print_Matrix() {
	int i, j;
	printf("Matrix A : \n");

	for (i = 0; i < N; i++) {
		printf("[");
		for (j = 0; j < N; j++)
			printf(" %5.2f, ", A[i][j]);

		printf("]\n");
	}

	printf("Vector b : \n[");
	for (j = 0; j < N; j++)
		printf(" %5.2f, ", b[j]);

	printf("]\n");
	printf("Vector y : \n[");
	for (j = 0; j < N; j++)
		printf(" %5.2f, ", y[j]);

	printf("]\n");
	printf("\n\n");
}

void Init_Default() {
	N = 2048;
	Init = "rand";
	maxnum = 15.0;
	PRINT = 0;
}

int Read_Options(int argc, char **argv) {
	char *prog;
	prog = *argv;
	while (++argv, --argc > 0)
		if (**argv == '-')
			switch (*++*argv) {
			case 'n': --argc;
				N = atoi(*++argv);
				break;

			case 'h': printf("\nHELP: try sor -u \n\n");
				exit(0);
				break;

			case 'u': printf("\nUsage: sor[-n problemsize]\n");
				printf("[-D] show default values \n");
				printf("[-h] help \n");
				printf("[-I init type] fast / rand \n");
				printf("[-m maxnum] max random no \n");
				printf("[-P print switch] 0 / 1 \n");
				exit(0);
				break;

			case 'D': printf("\nDefault: n = %d ", N);
				printf("\n Init = rand");
				printf("\n maxnum = 5 ");
				printf("\n P = 0 \n\n");
				exit(0);
				break;

			case 'I': --argc;
				Init = *++argv;
				break;

			case 'm':
				--argc;
				maxnum = atoi(*++argv);
				break;

			case 'P': --argc;
				PRINT = atoi(*++argv);
				break;

			default: printf("%s: ignored option : -%s\n", prog, *argv);
				printf("HELP: try %s -u \n\n", prog);
				break;
			}
}
